# UL Digital Portfolio (React + Vite + Tailwind + optional Firebase)

A clean, single-column academic portfolio website matching your screenshots and report.

## Quick start

```bash
npm install
npm run dev
```

## Optional: enable Firebase chat

Create a `.env` file in the project root:

```
VITE_USE_FIREBASE=true
VITE_FB_API_KEY=...your...
VITE_FB_AUTH_DOMAIN=...
VITE_FB_PROJECT_ID=...
VITE_FB_STORAGE_BUCKET=...
VITE_FB_MSG_SENDER_ID=...
VITE_FB_APP_ID=...
```

If you skip this step, the Chat page falls back to a local in-memory mock (works offline for demos).

## Pages

- Home, About, Education, Professional, Pictures, Videos, Blog, Chat, Certificates

## Tech

- React 18, Vite 5, Tailwind 3, React Router 6, (optional) Firebase Firestore

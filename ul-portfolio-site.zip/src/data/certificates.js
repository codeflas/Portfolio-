export const certificates = [
  { title: 'java basic', img: '/certs/java-basic.png' },
  { title: 'problem solving basic', img: '/certs/ps-basic.png' },
  { title: 'problem solving inter', img: '/certs/ps-inter.png' },
  { title: 'sql advanced', img: '/certs/sql-advanced.png' },
  { title: 'grearlearningcertificate (1)', img: '/certs/greatlearn.png' },
  { title: 'CAPM', img: '/certs/capm.png' },
  { title: 'non tech', img: '/certs/non-tech.png' },
]

export const posts = [
  { id: 1, title: 'Why a portfolio still matters', date: '2025-10-06', excerpt: 'A brief reflection on craft, clarity, and steady growth.' },
  { id: 2, title: 'Notes from a Spring Boot backend', date: '2025-10-01', excerpt: 'Small lessons from a layered service.' },
  { id: 3, title: 'Designing for readability', date: '2025-09-28', excerpt: 'Spacing, typography, and quiet detail.' }
]

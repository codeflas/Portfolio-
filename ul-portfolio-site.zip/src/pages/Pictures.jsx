export default function Pictures(){
  const imgs = Array.from({length:9}).map((_,i)=>({title:`Tech Image ${i+1}`}))
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-4">Picture Gallery</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {imgs.map(i => (
          <div key={i.title} className="border rounded-xl p-6 text-stone-400">{i.title}</div>
        ))}
      </div>
    </section>
  )
}

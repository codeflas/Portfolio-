export default function Professional(){
  const skills = ['Java','SQL','Python','C#','JavaScript','Spring Boot','Hibernate','REST APIs','Docker','Jenkins','PostgreSQL','MySQL','MS SQL Server','GCP','AWS (basic)']
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-2">Professional Knowledge</h2>
      <div className="grid md:grid-cols-2 gap-8">
        <div>
          <h3 className="font-semibold">Experience</h3>
          <p className="mt-1"><b>Johnson Controls — Intern (Pune)</b><br/>SQL data models, Power BI dashboards, .NET integration; automation scripts.</p>
          <p className="mt-3"><b>Code Interns — Python Developer (Bangalore)</b><br/>Automation and ETL pipelines; modular microservice‑style scripts.</p>
        </div>
        <div>
          <h3 className="font-semibold">Skills</h3>
          <div className="mt-2 flex flex-wrap gap-2">
            {skills.map(s => <span key={s} className="badge">{s}</span>)}
          </div>
        </div>
      </div>
    </section>
  )
}

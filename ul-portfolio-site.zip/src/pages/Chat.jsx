import { useEffect, useState } from 'react'

// If VITE_USE_FIREBASE is true, use Firestore; else use a local in-memory mock.
let useFirebase = import.meta.env.VITE_USE_FIREBASE === 'true'
let Messages
if (useFirebase) {
  try {
    Messages = (await import('../firebase.js')).Messages
  } catch (e) {
    console.warn('Firebase import failed, falling back to mock:', e)
    useFirebase = false
  }
}

function useMockMessages(){
  const [list, setList] = useState([
    {text:'Sample message 1 in the chat...', sender:'Guest'},
    {text:'Sample message 2 in the chat...', sender:'You'},
    {text:'Sample message 3 in the chat...', sender:'Guest'},
    {text:'Sample message 4 in the chat...', sender:'You'},
    {text:'Sample message 5 in the chat...', sender:'Guest'},
    {text:'Sample message 6 in the chat...', sender:'You'},
    {text:'Sample message 7 in the chat...', sender:'Guest'},
    {text:'Sample message 8 in the chat...', sender:'You'},
    {text:'Sample message 9 in the chat...', sender:'Guest'},
    {text:'Sample message 10 in the chat...', sender:'You'},
  ])
  const send = (t)=> setList(prev=>[...prev, {text:t, sender:'You'}])
  useEffect(()=>{},[])
  return { list, send }
}

export default function Chat(){
  const [text, setText] = useState('')
  const [list, setList] = useState([])

  useEffect(()=>{
    if (useFirebase && Messages){
      const unsub = Messages.listen(setList)
      return () => unsub && unsub()
    } else {
      // hydrate with mock on mount
      setList([
        {text:'Sample message 1 in the chat...', sender:'Guest'},
        {text:'Sample message 2 in the chat...', sender:'You'},
        {text:'Sample message 3 in the chat...', sender:'Guest'},
        {text:'Sample message 4 in the chat...', sender:'You'},
        {text:'Sample message 5 in the chat...', sender:'Guest'},
        {text:'Sample message 6 in the chat...', sender:'You'},
        {text:'Sample message 7 in the chat...', sender:'Guest'},
        {text:'Sample message 8 in the chat...', sender:'You'},
        {text:'Sample message 9 in the chat...', sender:'Guest'},
        {text:'Sample message 10 in the chat...', sender:'You'},
      ])
    }
  }, [])

  async function send(){
    if(!text.trim()) return
    if (useFirebase && Messages){
      await Messages.send(text.trim())
    } else {
      setList(prev=>[...prev, {text:text.trim(), sender:'You'}])
    }
    setText('')
  }

  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-4">Instant Messaging</h2>
      <div className="border rounded-xl p-4 h-72 overflow-auto space-y-2">
        {list.map((m, idx)=>(
          <div key={idx} className="text-sm"><b>{m.sender}:</b> {m.text}</div>
        ))}
      </div>
      <div className="mt-3 flex gap-2">
        <input value={text} onChange={e=>setText(e.target.value)} className="flex-1 border rounded-full px-3 py-2 text-sm" />
        <button onClick={send} className="px-4 py-2 rounded-full bg-stone-800 text-white">Send</button>
      </div>
    </section>
  )
}

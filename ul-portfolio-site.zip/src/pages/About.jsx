export default function About(){
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-2">About</h2>
      <p className="leading-relaxed">I'm pursuing the MSc in Software Engineering at the University of Limerick (2025–2026). My interests span distributed systems, data‑driven services, and pragmatic engineering practices. Previously, I completed a BE in Computer Science at PCCOER with a CGPA of 9. I enjoy building robust backends, shaping clean APIs, and designing simple interfaces that foreground content.</p>
    </section>
  )
}

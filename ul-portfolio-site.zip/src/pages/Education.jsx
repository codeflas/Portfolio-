export default function Education(){
  const items = [
    {org:'University of Limerick, Ireland', details:'MSc in Software Engineering • 2025–2026 • GPA: 3.5'},
    {org:'PCCOER — Pimpri Chinchwad College of Engineering and Research', details:'BE in Computer Science • 2021–2025 • CGPA: 9'},
    {org:'Vidya Valley Highschool', details:'HSC Maharashtra • 2021 • 87.17%'},
  ]
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-4">Education</h2>
      <ul className="space-y-5">
        {items.map((it, idx) => (
          <li key={idx}>
            <div className="font-semibold">{it.org}</div>
            <div className="text-stone-600 text-sm">{it.details}</div>
            <hr className="mt-3" />
          </li>
        ))}
      </ul>
    </section>
  )
}

export default function Videos(){
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-4">Video Gallery</h2>
      <div className="space-y-6">
        <div className="border rounded-xl p-6 text-stone-400">Embedded Video 1</div>
        <div className="border rounded-xl p-6 text-stone-400">Embedded Video 2</div>
      </div>
    </section>
  )
}

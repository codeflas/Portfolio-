import { posts } from '../data/blog'

export default function Blog(){
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-4">Blog</h2>
      <input placeholder="Search..." className="w-full border rounded-full px-3 py-2 text-sm mb-4" />
      <div className="space-y-4">
        {posts.map(p => (
          <article key={p.id} className="border rounded-xl p-5">
            <div className="flex items-baseline justify-between gap-6">
              <div>
                <h3 className="font-semibold">{p.title}</h3>
                <p className="text-stone-600 text-sm">{p.excerpt}</p>
              </div>
              <div className="text-stone-500 text-sm">{p.date}</div>
            </div>
          </article>
        ))}
      </div>
    </section>
  )
}

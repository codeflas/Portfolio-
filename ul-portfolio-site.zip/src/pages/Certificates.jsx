import { certificates } from '../data/certificates'

export default function Certificates(){
  return (
    <section className="card">
      <h2 className="text-2xl font-bold mb-4">Certificates</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {certificates.map((c,idx)=>(
          <figure key={idx} className="border rounded-xl p-3">
            <img src={c.img} alt={c.title} className="w-full aspect-video object-contain rounded-md" />
            <figcaption className="mt-2 text-sm text-stone-700">{c.title}</figcaption>
          </figure>
        ))}
      </div>
    </section>
  )
}

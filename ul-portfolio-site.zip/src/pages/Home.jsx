export default function Home(){
  return (
    <section className="card">
      <div className="grid grid-cols-1 md:grid-cols-[1fr,220px] gap-8 items-center">
        <div>
          <h1 className="text-4xl font-bold text-stone-800">Shubham Biradar</h1>
          <p className="text-stone-600 mt-2">MSc in Software Engineering — University of Limerick</p>
          <div className="mt-4 flex gap-3">
            <a href="https://www.linkedin.com/in/shubham-biradar-30a91b236" target="_blank" className="badge">LinkedIn</a>
            <a href="https://github.com/codeflas/Portfolio-" target="_blank" className="badge">GitHub</a>
          </div>
          <p className="mt-6 leading-relaxed">Building reliable backends, thoughtful interfaces, and clear systems.</p>
        </div>
        <div className="justify-self-center md:justify-self-end">
          <img src="/avatar.png" alt="Shubham" className="rounded-full w-[200px] h-[200px] object-cover" />
        </div>
      </div>
    </section>
  )
}

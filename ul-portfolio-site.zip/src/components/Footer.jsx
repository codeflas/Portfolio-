export default function Footer(){
  return (
    <footer className="mt-10 py-10 text-center text-xs text-stone-500">
      CS5709 – Software Engineering Evolution | University of Limerick | 2025/6 Sem 1
    </footer>
  )
}

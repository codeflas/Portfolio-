import { NavLink } from 'react-router-dom'

const NavItem = ({to, children}) => (
  <NavLink to={to} className={({isActive}) => `nav-link ${isActive ? 'font-semibold text-ul-green' : ''}`}>
    {children}
  </NavLink>
)

export default function Navbar(){
  return (
    <header className="bg-stone-200/60 backdrop-blur border-b border-stone-300">
      <div className="container-narrow py-3 flex flex-wrap gap-4 items-center justify-between">
        <div className="font-semibold">Digital Portfolio</div>
        <nav className="flex gap-5 text-sm">
          <NavItem to="/">Home</NavItem>
          <NavItem to="/about">About</NavItem>
          <NavItem to="/education">Education</NavItem>
          <NavItem to="/professional">Professional</NavItem>
          <NavItem to="/pictures">Pictures</NavItem>
          <NavItem to="/videos">Videos</NavItem>
          <NavItem to="/blog">Blog</NavItem>
          <NavItem to="/chat">Chat</NavItem>
          <NavItem to="/certificates">Certificates</NavItem>
        </nav>
      </div>
    </header>
  )
}

// Optional Firebase config. Populate .env with your keys and set VITE_USE_FIREBASE=true to enable.
import { initializeApp } from 'firebase/app'
import { getFirestore, collection, addDoc, onSnapshot, orderBy, query, serverTimestamp } from 'firebase/firestore'

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FB_API_KEY,
  authDomain: import.meta.env.VITE_FB_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FB_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FB_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FB_MSG_SENDER_ID,
  appId: import.meta.env.VITE_FB_APP_ID
}

export const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)

export const Messages = {
  listen(cb){
    const q = query(collection(db,'messages'), orderBy('ts'))
    return onSnapshot(q, (snap)=> cb(snap.docs.map(d=>d.data())))
  },
  async send(text){
    await addDoc(collection(db,'messages'), { text, sender:'You', ts: serverTimestamp() })
  }
}

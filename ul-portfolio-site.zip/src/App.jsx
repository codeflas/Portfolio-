import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Footer from './components/Footer.jsx'
import Home from './pages/Home.jsx'
import About from './pages/About.jsx'
import Education from './pages/Education.jsx'
import Professional from './pages/Professional.jsx'
import Pictures from './pages/Pictures.jsx'
import Videos from './pages/Videos.jsx'
import Blog from './pages/Blog.jsx'
import Chat from './pages/Chat.jsx'
import Certificates from './pages/Certificates.jsx'

export default function App(){
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="container-narrow flex-1 py-8">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/education" element={<Education />} />
          <Route path="/professional" element={<Professional />} />
          <Route path="/pictures" element={<Pictures />} />
          <Route path="/videos" element={<Videos />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/chat" element={<Chat />} />
          <Route path="/certificates" element={<Certificates />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
